drop table audit;
drop table accounts;
drop table parking_rates;
drop table parking_size_history;
drop table payments;
drop table tickets;
drop table parking_availability_history;
drop table payment_exceptions;