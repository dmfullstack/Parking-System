package cs414.fmaster.parking.controller;
/**
 * @author masterf
 *
 */
public enum GateType {
	Entry,
	Exit
}
