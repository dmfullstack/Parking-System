/**
 * 
 */
package cs414.fmaster.parking.controller;

/**
 * @author MasterF
 *
 */
public class ParkingRate {
	private double hours;
	private double rate;

	public double getHours() {
		return hours;
	}
	public double getRate() {
		return rate;
	}
	public void setHours(double hours) {
		this.hours = hours;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}

}
